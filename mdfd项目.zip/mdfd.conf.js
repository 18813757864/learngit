/**
 * 项目基本配置
 */
module.exports = {
  // 项目名称
  name: "wuwf",
  // 编译环境
  env: "pc",
  // 是否mock环境
  isMock: true,
  // 开发环境网络配置
  devServer: {
    // 设置代理
    proxy: {},
    // 默认端口
    port: "8080",
    // 设置默认打开页面(路由)
    openUrl: ""
  },
  // 线上部署
  server: {
    host: "", // 服务器地址
    port: 22,
    path: "" // 存放地址
  },
  // wepack额外配置
  extraWebpack: {
    module: {
      lessLoader: {
        loader: "less-loader",
        options: {
          modifyVars: {
            "primary-color": "#1DA57A",
            "link-color": "#1DA57A",
            "border-radius-base": "2px"
          },
          javascriptEnabled: true
        }
      }
    }
  }
};
