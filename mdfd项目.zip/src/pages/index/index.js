/**
 * 页面入口
 */

// 功能 - 通用内容
import "@/common/js/resoures";
// 框架 - vue
import Vue from "vue";
// 框架 - vuex
import store from "@/store";
// 组件 - 根组件
import App from "./app.vue";
// 功能 - 路由
import router from "@/router";

// 实例化
const indexLogin = new Vue({
  el: "#app",
  router,
  store,
  components: {
    App
  },
  template: "<App/>"
});
Vue.use({
  indexLogin
});