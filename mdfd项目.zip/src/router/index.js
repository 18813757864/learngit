import Vue from "vue";
import Router from "vue-router";
// 页面 - 404
import NoFound from "@/views/404";
// 页面 - 登录
import Login from "@/views/login";

// 项目基本配置
const config = require("../../mdfd.conf");

Vue.use(Router);

// 路由配置
const configRoutes = [
  {
    path: "/",
    redirect: "/login"
  },
  {
    path: "/login",
    name: "login",
    component: Login
  },
  {
    path: "*",
    component: NoFound
  }
];

export default new Router({
  base: `/${config.name}`,
  mode: "history",
  routes: configRoutes
});
