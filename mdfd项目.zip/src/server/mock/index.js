/**
 * mock - 入口
 */
// 获取登录
import "./login";

// 通用配置
const Mock = require("mockjs");

Mock.setup({
  timeout: 0 - 300
});
