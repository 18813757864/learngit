import Mock from "mockjs";
import ApiPath from "../apiList/common";

Mock.mock(ApiPath.login, "post", {
  status: 200,
  type: "SUCCESS",
  desc: "登录成功",
  time: "20190412103402771",
  data: {
    applicationCode: "MD_XCPYB_OA",
    sessionId: "c4eb092e-fd44-4674-b219-e0f64fd9dd59"
  }
});
