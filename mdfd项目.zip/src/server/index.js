/**
 * 功能 - 封装axios
 */
import axios from "axios";

const Axios = axios.create({
  timeout: 12000,
  withCredentials: true,
  headers: {
    "X-Requested-With": "XMLHttpRequest"
  }
});

// 请求拦截
Axios.interceptors.request.use(
  config => {
    // TODO:根据错误提示弹窗
    return config;
  },
  err => {
    // TODO:根据错误提示弹窗

    return Promise.resolve(err);
  }
);
// 响应拦截
Axios.interceptors.response.use(
  data => {
    // TODO:根据错误提示弹窗
    if (data.status && data.status === 200 && data.data.status === "error") {
      return false;
    }
    return data.data.data;
  },
  err => {
    // const { status } = err.response;

    // TODO:根据错误提示弹窗
    // if (status === 504 || status === 404) {
    // } else if (status === 403) {
    // } else {
    // }
    return Promise.resolve(err);
  }
);

export default Axios;
