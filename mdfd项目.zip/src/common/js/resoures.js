/**
 * 通用资源
 */
import Vue from "vue";
// 基础资源 - antd-md-component
import "@/common/js/antdMd";

// 功能 - 网络请求
import Axios from "@/server";
// 功能 - 通用方法
import Utils from "@/tools/utils";

// 样式 - 通用样式
import "../style/base.less";

// 基础 - 项目配置
const config = require("../../../mdfd.conf");
// 功能 - mock
if (config.isMock) {
  require("@/server/mock");
}

Vue.config.productionTip = false;

Vue.prototype.$Axios = Axios;
Vue.prototype.$Utils = Utils;

Vue.prototype.$Bus = new Vue();
