/**
 * antd-md-component引入资源
 */
// 框架 - vue
import Vue from "vue";
import {
  Button,
  Checkbox,
  Col,
  Icon,
  Layout,
  Form,
  message,
  Radio,
  Input,
  Select,
  Row
} from "antd-md-component";

Vue.use(Button);
Vue.use(Checkbox);
Vue.use(Col);
Vue.use(Form);
Vue.use(Icon);
Vue.use(Input);
Vue.use(Select);
Vue.use(Layout);
Vue.use(Radio);
Vue.use(Row);

Vue.prototype.$message = message;
Vue.prototype.$form = Form;
