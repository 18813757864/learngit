<template>
  <div class="page-login-wrap">
    <a-button type="primary">Primary</a-button>
    <a-button>Default</a-button>
    <a-button type="dashed">Dashed</a-button>
    <a-button type="danger">Danger</a-button>
    <a-icon type="step-backward" />
  </div>
  
</template>

<script>
export default {
  data() {
    return {};
  },
  created() {
    this.$Utils.setTitle("登录");
  },
  methods: {}
};
</script>

<style lang="less" scoped>
.page-login-wrap {
  width: 100%;
  height: 100%;
}
</style>
