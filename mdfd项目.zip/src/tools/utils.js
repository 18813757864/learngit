/**
 * 工具方法
 */
class Utils {
  /**
   * 设置图片
   * image: 传进来的图片地址
   */
  styleImage(image) {
    this.image = image;
    return {
      background: `url(${image}) no-repeat`,
      backgroundSize: "100% 100%"
    };
  }

  /**
   * 设置标题
   * @param {*} title
   */
  setTitle(title) {
    setTimeout(() => {
      // 利用iframe的onload事件刷新页面
      document.title = title;
      const iframe = document.createElement("iframe");
      iframe.style.visibility = "hidden";
      iframe.style.width = "1px";
      iframe.style.height = "1px";
      iframe.onload = () => {
        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 0);
      };
      document.body.appendChild(iframe);
    }, 0);
  }

  /**
   * 获取地址栏参数
   * @param {*} url 地址栏url
   */
  getUrlParam(url = window.location) {
    const obj = {};
    let r = [];
    // 判断是否地址对象
    if (url.origin) {
      if (url.search) {
        r = url.search.split("?");
      } else if (url.hash) {
        r = url.hash.split("?");
      }
    } else {
      r = url.split("?");
    }
    if (r.length > 0) {
      const result = r[1].split("&");
      result.forEach(item => {
        const temp = item.split("=");
        [obj[temp[0]]] = [temp[1]];
      });
    }
    return obj;
  }
}
export default new Utils();
