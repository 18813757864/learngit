/**
 *author: kyh
 *date: 2019-04-04
 *describe: 设置cookie
*/
export default {
  // 设置cookie
  setCookie: (name, value, min) => {
    const exp = new Date();
    exp.setTime(exp.getTime() + min * 60 * 1000);
    document.cookie = `${name}=${escape(value)};expires=${exp.toGMTString()};path=/`;
  }
  // 获取cookie
  // getCookie: name => {
  //   let arr;
  //   const reg = new RegExp(`(^| )${name}=([^;]*)(;|$)`);
  //   if (arr === document.cookie.match(reg)) {
  //     // return unescape(arr[2]);
  //   }
  // },
  // 删除cookie
  // delCookie: name => {
  //   const exp = new Date();
  //   exp.setTime(exp.getTime() - 1);
  //   const val = getCookie(name);
  //   if (val != null) {
  //     document.cookie = `${name}=${cval};expires=${exp.toGMTString()}`;
  //   }
  // }
};
