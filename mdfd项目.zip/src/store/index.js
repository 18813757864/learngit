// vuex
import Vue from "vue";
import Vuex from "vuex";
// 模块 - 系统
import app from "./modules/app";

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    app
  }
});
