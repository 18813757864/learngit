<!--
 * @Descripttion: 组件入口
 * @Author: wwf
 * @Date: 2019-08-22 11:41:40
 * @LastEditors: jack_huang
 * @LastEditTime: 2019-08-30 11:57:18
 -->
<script>
export default {
  name: "mdTemplate",
  props: {},
  data() {
    return {};
  },
  methods: {},
  render() {
    return <div>这里是开发具体组件地方</div>;
  }
};
</script>

