<!--
 * @Descripttion: 
 * @Author: jack_huang
 * @Date: 2019-08-29 17:08:35
 * @LastEditors: jack_huang
 * @LastEditTime: 2019-08-30 11:28:30
 -->
## API

通过设置 Button 的属性来产生不同的按钮样式，推荐顺序为：`type` -> `shape` -> `size` -> `loading` -> `disabled`

按钮的属性说明如下：

| 属性     | 说明         | 类型    | 默认值  |
| -------- | ------------ | ------- | ------- |
| disabled | 按钮失效状态 | boolean | `false` |

### 事件
| 事件名称 | 说明             | 回调参数        |
| -------- | ---------------- | --------------- |
| click    | 点击按钮时的回调 | (event) => void |


