<!--
 * @Descripttion: 组件 - 例子 - 入口 
 * @Author: jack_huang
 * @Date: 2019-08-22 11:43:43
 * @LastEditors: jack_huang
 * @LastEditTime: 2019-08-30 11:25:34
 -->
<script>
import Basic from "./basic.md";

import CN from "./api.zh-CN.md";
import US from "./api.en-CN.md";
const md = {
  cn: `# Template 模版
          这里是简单的说明。
          ## 何时使用
          标记了一个（或封装一组）操作命令，响应用户点击行为，触发相应的业务逻辑。
          ## 组件注册
          \`\`\`js
          import { Template } from 'Template';
          Vue.use(Template);
          \`\`\`
          ## 代码演示`,
  us: `# 根据中文进行英文撰写
          `
};
export default {
  render() {
    return (
      <div class="md-wrap">
        <Basic />
        <api>
          <CN slot="cn" />
          <US />
        </api>
      </div>
    );
  }
};
</script>

<style lang="less">
.md-wrap {
  padding: 20px;
}
[id^="components-button-demo-"] .ant-btn {
  margin-right: 8px;
  margin-bottom: 12px;
}
[id^="components-button-demo-"] .ant-btn-group > .ant-btn {
  margin-right: 0;
}
</style>

