<!--
 * @Descripttion: 
 * @Author: jack_huang
 * @Date: 2019-08-29 14:25:53
 * @LastEditors: jack_huang
 * @LastEditTime: 2019-08-30 11:27:19
 -->

<cn>
#### 基本使用
这里写使用说明
</cn>

<us>
#### 这里写英文
</us>

```html
<template>
  <div>
    <md-template></md-template>
  </div>
</template>
```

