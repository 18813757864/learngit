/*
 * @Descripttion: 安装组件
 * @Author: wwf
 * @Date: 2019-08-22 11:41:40
 * @LastEditors: wwf
 * @LastEditTime: 2019-08-30 11:54:11
 */
import Template from "./template.vue";

Template.install = Vue => {
  Vue.component(Template.name, Template);
};

export default Template;
