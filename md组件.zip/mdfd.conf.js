/*
 * @Descripttion:
 * @Author: wwf
 * @Date: 2019-08-28 10:06:05
 * @LastEditors: jack_huang
 * @LastEditTime: 2019-08-30 11:53:23
 */
/**
 * 项目基本配置
 */
module.exports = {
  // 项目名称
  name: "wwf",
  // 编译环境
  env: "component",
  // 开发环境网络配置
  devServer: {
    // 设置代理
    proxy: {},
    // 默认端口
    port: "8082",
    // 设置默认打开页面(路由)
    openUrl: ""
  }
};
