<!--
 * @Descripttion: 说明文档
 * @Author: wwf
 * @Date: 2019-08-30 11:39:55
 * @LastEditors: jack_huang
 * @LastEditTime: 2019-08-30 11:57:52
 -->
### 组件模版

## 运行命令
``` bash

# 开发模式
mdfd watch
# 生产模式
mdfd watch

```
---

## 使用注意
1. 默认已经全局引入了antd-md-component组件库,调用组件直接根据平台说明